document.getElementById("checkBtn").addEventListener("click", detectLanguage);

function detectLanguage() {
    const text = document.getElementById("textInput").value.trim();
    const resultElement = document.getElementById("result");

    if (text === "") {
        resultElement.textContent = "判定結果: テキストを入力してください";
        return;
    }

    // 各文字種の判定
    const hasHiragana = /[\u3040-\u309F]/.test(text);
    const hasKatakana = /[\u30A0-\u30FF]/.test(text);
    const hasKanji = /[\u4E00-\u9FFF]/.test(text);
    const hasHangul = /[\uAC00-\uD7AF]/.test(text);
    const hasLatin = /[A-Za-z]/.test(text);
    const hasCyrillic = /[\u0400-\u04FF]/.test(text);

    let language = "不明";

    if (hasHangul) {
        language = "韓国語";
    } 
    else if (hasHiragana || hasKatakana) {
        language = "日本語";
    } 
    else if (hasKanji && !hasHiragana && !hasKatakana) {
        language = "中国語の可能性が高い";
    } 
    else if (hasCyrillic) {
        language = "ロシア語（キリル文字）";
    } 
    else if (hasLatin) {
        language = "英語またはラテン文字言語";
    }

    resultElement.textContent = "判定結果: " + language;
}
